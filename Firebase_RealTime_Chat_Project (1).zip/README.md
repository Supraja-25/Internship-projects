
Firebase Real-Time Chat App

1. Create Firebase Project
2. Enable Firestore Database
3. Replace firebaseConfig in src/firebase.js
4. npm install
5. npm start
