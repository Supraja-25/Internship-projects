
import { useState, useEffect } from 'react';
import { db } from './firebase';
import {
 collection,
 addDoc,
 query,
 orderBy,
 onSnapshot
} from 'firebase/firestore';

function App() {
 const [message, setMessage] = useState('');
 const [messages, setMessages] = useState([]);

 useEffect(() => {
   const q = query(collection(db, 'messages'), orderBy('createdAt'));
   const unsub = onSnapshot(q, (snapshot) => {
     setMessages(snapshot.docs.map(doc => doc.data()));
   });
   return () => unsub();
 }, []);

 const sendMessage = async () => {
   if (!message) return;

   await addDoc(collection(db, 'messages'), {
     text: message,
     createdAt: Date.now()
   });

   setMessage('');
 };

 return (
   <div style={{padding:'20px'}}>
     <h1>Firebase Real-Time Chat</h1>

     <div>
       {messages.map((msg, i) => (
         <p key={i}>{msg.text}</p>
       ))}
     </div>

     <input
       value={message}
       onChange={(e) => setMessage(e.target.value)}
       placeholder="Type message"
     />
     <button onClick={sendMessage}>Send</button>
   </div>
 );
}

export default App;
