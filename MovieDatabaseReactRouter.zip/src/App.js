import { BrowserRouter, Routes, Route, Link, useParams } from 'react-router-dom';

const movies = [
  { id: 1, title: 'Inception', year: 2010 },
  { id: 2, title: 'Interstellar', year: 2014 },
  { id: 3, title: 'Avatar', year: 2009 }
];

function Home() {
  return (
    <div>
      <h2>Movie Database</h2>
      {movies.map(movie => (
        <p key={movie.id}>
          <Link to={`/movie/${movie.id}`}>{movie.title}</Link>
        </p>
      ))}
    </div>
  );
}

function MovieDetails() {
  const { id } = useParams();
  const movie = movies.find(m => m.id === Number(id));
  return movie ? (
    <div>
      <h2>{movie.title}</h2>
      <p>Year: {movie.year}</p>
      <Link to="/">Back</Link>
    </div>
  ) : <h2>Movie Not Found</h2>;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/movie/:id" element={<MovieDetails />} />
      </Routes>
    </BrowserRouter>
  );
}
