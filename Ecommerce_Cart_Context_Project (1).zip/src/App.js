
import { CartProvider, useCart } from './context/CartContext';

const products = [
  { id: 1, name: 'Laptop', price: 50000 },
  { id: 2, name: 'Phone', price: 25000 }
];

function Shop() {
  const { cart, addToCart, removeFromCart } = useCart();

  return (
    <div style={{padding:'20px'}}>
      <h1>E-Commerce Cart (Context API)</h1>

      <h2>Products</h2>
      {products.map(p => (
        <div key={p.id}>
          {p.name} - ₹{p.price}
          <button onClick={() => addToCart(p)}> Add</button>
        </div>
      ))}

      <h2>Cart ({cart.length})</h2>
      {cart.map(item => (
        <div key={item.id}>
          {item.name}
          <button onClick={() => removeFromCart(item.id)}> Remove</button>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <Shop />
    </CartProvider>
  );
}
