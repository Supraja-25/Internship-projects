
# MERN Blog Project

Backend:
cd backend
npm install
npm start

Frontend:
cd frontend
npm install
npm start

MongoDB should be running locally.
