
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://127.0.0.1:27017/blogdb');

const PostSchema = new mongoose.Schema({
  title: String,
  content: String,
}, { timestamps: true });

const Post = mongoose.model('Post', PostSchema);

app.get('/api/posts', async (req,res)=>{
  res.json(await Post.find().sort({createdAt:-1}));
});

app.post('/api/posts', async (req,res)=>{
  const post = await Post.create(req.body);
  res.json(post);
});

app.listen(5000, ()=>console.log('Server running on 5000'));
