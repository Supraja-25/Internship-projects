
import React,{useEffect,useState} from 'react';
import axios from 'axios';

function App(){
 const [posts,setPosts]=useState([]);
 const [title,setTitle]=useState('');
 const [content,setContent]=useState('');

 const load=async()=>{
   const res=await axios.get('http://localhost:5000/api/posts');
   setPosts(res.data);
 };
 useEffect(()=>{load();},[]);

 const submit=async()=>{
   await axios.post('http://localhost:5000/api/posts',{title,content});
   setTitle(''); setContent('');
   load();
 };

 return (
  <div style={{padding:'20px'}}>
   <h1>IT Tech Solutions Blog</h1>
   <input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
   <br/><br/>
   <textarea placeholder="Content" value={content} onChange={e=>setContent(e.target.value)} />
   <br/><br/>
   <button onClick={submit}>Publish</button>
   <hr/>
   {posts.map(p=><div key={p._id}><h3>{p.title}</h3><p>{p.content}</p></div>)}
  </div>
 );
}
export default App;
